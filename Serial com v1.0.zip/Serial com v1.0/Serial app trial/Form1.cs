﻿/*AUTHOR : SHEHAN SOORIYAARACHCHI*/


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;

namespace Serial_app_trial
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        string dataOut;

        private void Form1_Load(object sender, EventArgs e)
        {
            string[] ports = SerialPort.GetPortNames();
            cBox_PORTNAME.Items.AddRange(ports);
        }

        private void lbl_PARITYBITS_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void cBox_PORTNAME_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void cBox_STOPBITS_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btn_OPEN_Click(object sender, EventArgs e)
        {
            try
            {
                serialPort1.PortName =  cBox_PORTNAME.Text;
                serialPort1.BaudRate =  Convert.ToInt32(cBox_BAUDRATE.Text);
                serialPort1.DataBits =  Convert.ToInt32(cBox_DATABITS.Text);   // 8 for arduino
                serialPort1.StopBits =  (StopBits)Enum.Parse(typeof(StopBits), cBox_STOPBITS.Text); //stopBits.one
                serialPort1.Parity   =  (Parity)Enum.Parse(typeof(Parity), cBox_PARITYBITS.Text); //parity.None
                serialPort1.Open();
                progressBar1.Value = 100;
            }

            catch (Exception x) { 
            
               MessageBox.Show(x.Message);
            }
           
        }

        private void btn_CLOSE_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen) { serialPort1.Close(); }
            progressBar1.Value = 0;
        }

        private void btn_SEND_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen) {

                dataOut = textBox1.Text;
                serialPort1.WriteLine(dataOut);
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            textBox2.Text = serialPort1.ReadLine();
        }

        private void lbl_PORTNAME_Click(object sender, EventArgs e)
        {

        }


    }
}
