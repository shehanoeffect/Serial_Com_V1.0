﻿/*******
 * AUTHOR : SHEHAN SOORIYAARACHCHI
 * */



namespace Serial_app_trial
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cBox_BAUDRATE = new System.Windows.Forms.ComboBox();
            this.cBox_PARITYBITS = new System.Windows.Forms.ComboBox();
            this.cBox_STOPBITS = new System.Windows.Forms.ComboBox();
            this.cBox_DATABITS = new System.Windows.Forms.ComboBox();
            this.lbl_PARITYBITS = new System.Windows.Forms.Label();
            this.lbl_STOPBITS = new System.Windows.Forms.Label();
            this.lbl_DATABITS = new System.Windows.Forms.Label();
            this.lbl_BAUDRATE = new System.Windows.Forms.Label();
            this.lbl_PORTNAME = new System.Windows.Forms.Label();
            this.cBox_PORTNAME = new System.Windows.Forms.ComboBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.btn_CLOSE = new System.Windows.Forms.Button();
            this.btn_OPEN = new System.Windows.Forms.Button();
            this.btn_SEND = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cBox_BAUDRATE);
            this.groupBox1.Controls.Add(this.cBox_PARITYBITS);
            this.groupBox1.Controls.Add(this.cBox_STOPBITS);
            this.groupBox1.Controls.Add(this.cBox_DATABITS);
            this.groupBox1.Controls.Add(this.lbl_PARITYBITS);
            this.groupBox1.Controls.Add(this.lbl_STOPBITS);
            this.groupBox1.Controls.Add(this.lbl_DATABITS);
            this.groupBox1.Controls.Add(this.lbl_BAUDRATE);
            this.groupBox1.Controls.Add(this.lbl_PORTNAME);
            this.groupBox1.Controls.Add(this.cBox_PORTNAME);
            this.groupBox1.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(292, 237);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "COM PORT CONTROL";
            // 
            // cBox_BAUDRATE
            // 
            this.cBox_BAUDRATE.FormattingEnabled = true;
            this.cBox_BAUDRATE.Items.AddRange(new object[] {
            "9600",
            "14400",
            "19200",
            "28800",
            "31250",
            "38400",
            "57600",
            "115200"});
            this.cBox_BAUDRATE.Location = new System.Drawing.Point(139, 77);
            this.cBox_BAUDRATE.Name = "cBox_BAUDRATE";
            this.cBox_BAUDRATE.Size = new System.Drawing.Size(121, 24);
            this.cBox_BAUDRATE.TabIndex = 14;
            // 
            // cBox_PARITYBITS
            // 
            this.cBox_PARITYBITS.FormattingEnabled = true;
            this.cBox_PARITYBITS.Items.AddRange(new object[] {
            "None",
            "Odd",
            "Even"});
            this.cBox_PARITYBITS.Location = new System.Drawing.Point(139, 168);
            this.cBox_PARITYBITS.Name = "cBox_PARITYBITS";
            this.cBox_PARITYBITS.Size = new System.Drawing.Size(121, 24);
            this.cBox_PARITYBITS.TabIndex = 13;
            // 
            // cBox_STOPBITS
            // 
            this.cBox_STOPBITS.FormattingEnabled = true;
            this.cBox_STOPBITS.Items.AddRange(new object[] {
            "",
            "One",
            "Two"});
            this.cBox_STOPBITS.Location = new System.Drawing.Point(139, 137);
            this.cBox_STOPBITS.Name = "cBox_STOPBITS";
            this.cBox_STOPBITS.Size = new System.Drawing.Size(121, 24);
            this.cBox_STOPBITS.TabIndex = 12;
            this.cBox_STOPBITS.SelectedIndexChanged += new System.EventHandler(this.cBox_STOPBITS_SelectedIndexChanged);
            // 
            // cBox_DATABITS
            // 
            this.cBox_DATABITS.FormattingEnabled = true;
            this.cBox_DATABITS.Items.AddRange(new object[] {
            "6",
            "7",
            "8"});
            this.cBox_DATABITS.Location = new System.Drawing.Point(139, 107);
            this.cBox_DATABITS.Name = "cBox_DATABITS";
            this.cBox_DATABITS.Size = new System.Drawing.Size(121, 24);
            this.cBox_DATABITS.TabIndex = 11;
            // 
            // lbl_PARITYBITS
            // 
            this.lbl_PARITYBITS.AutoSize = true;
            this.lbl_PARITYBITS.BackColor = System.Drawing.Color.Transparent;
            this.lbl_PARITYBITS.Font = new System.Drawing.Font("Microsoft Sans Serif", 5.8F);
            this.lbl_PARITYBITS.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbl_PARITYBITS.Location = new System.Drawing.Point(34, 173);
            this.lbl_PARITYBITS.Name = "lbl_PARITYBITS";
            this.lbl_PARITYBITS.Size = new System.Drawing.Size(68, 13);
            this.lbl_PARITYBITS.TabIndex = 10;
            this.lbl_PARITYBITS.Text = "PARITY BITS";
            this.lbl_PARITYBITS.Click += new System.EventHandler(this.lbl_PARITYBITS_Click);
            // 
            // lbl_STOPBITS
            // 
            this.lbl_STOPBITS.AutoSize = true;
            this.lbl_STOPBITS.BackColor = System.Drawing.Color.Transparent;
            this.lbl_STOPBITS.Font = new System.Drawing.Font("Microsoft Sans Serif", 5.8F);
            this.lbl_STOPBITS.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbl_STOPBITS.Location = new System.Drawing.Point(34, 142);
            this.lbl_STOPBITS.Name = "lbl_STOPBITS";
            this.lbl_STOPBITS.Size = new System.Drawing.Size(59, 13);
            this.lbl_STOPBITS.TabIndex = 9;
            this.lbl_STOPBITS.Text = "STOP BITS";
            // 
            // lbl_DATABITS
            // 
            this.lbl_DATABITS.AutoSize = true;
            this.lbl_DATABITS.BackColor = System.Drawing.Color.Transparent;
            this.lbl_DATABITS.Font = new System.Drawing.Font("Microsoft Sans Serif", 5.8F);
            this.lbl_DATABITS.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbl_DATABITS.Location = new System.Drawing.Point(34, 112);
            this.lbl_DATABITS.Name = "lbl_DATABITS";
            this.lbl_DATABITS.Size = new System.Drawing.Size(59, 13);
            this.lbl_DATABITS.TabIndex = 8;
            this.lbl_DATABITS.Text = "DATA BITS";
            // 
            // lbl_BAUDRATE
            // 
            this.lbl_BAUDRATE.AutoSize = true;
            this.lbl_BAUDRATE.BackColor = System.Drawing.Color.Transparent;
            this.lbl_BAUDRATE.Font = new System.Drawing.Font("Microsoft Sans Serif", 5.8F);
            this.lbl_BAUDRATE.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbl_BAUDRATE.Location = new System.Drawing.Point(34, 82);
            this.lbl_BAUDRATE.Name = "lbl_BAUDRATE";
            this.lbl_BAUDRATE.Size = new System.Drawing.Size(65, 13);
            this.lbl_BAUDRATE.TabIndex = 7;
            this.lbl_BAUDRATE.Text = "BAUD RATE";
            // 
            // lbl_PORTNAME
            // 
            this.lbl_PORTNAME.AutoSize = true;
            this.lbl_PORTNAME.BackColor = System.Drawing.Color.Transparent;
            this.lbl_PORTNAME.Font = new System.Drawing.Font("Microsoft Sans Serif", 5.8F);
            this.lbl_PORTNAME.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbl_PORTNAME.Location = new System.Drawing.Point(35, 52);
            this.lbl_PORTNAME.Name = "lbl_PORTNAME";
            this.lbl_PORTNAME.Size = new System.Drawing.Size(67, 13);
            this.lbl_PORTNAME.TabIndex = 6;
            this.lbl_PORTNAME.Text = "PORT NAME";
            this.lbl_PORTNAME.Click += new System.EventHandler(this.lbl_PORTNAME_Click);
            // 
            // cBox_PORTNAME
            // 
            this.cBox_PORTNAME.FormattingEnabled = true;
            this.cBox_PORTNAME.Location = new System.Drawing.Point(139, 47);
            this.cBox_PORTNAME.Name = "cBox_PORTNAME";
            this.cBox_PORTNAME.Size = new System.Drawing.Size(121, 24);
            this.cBox_PORTNAME.TabIndex = 0;
            this.cBox_PORTNAME.SelectedIndexChanged += new System.EventHandler(this.cBox_PORTNAME_SelectedIndexChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.progressBar1);
            this.groupBox2.Controls.Add(this.btn_CLOSE);
            this.groupBox2.Controls.Add(this.btn_OPEN);
            this.groupBox2.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.groupBox2.Location = new System.Drawing.Point(37, 271);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(194, 146);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "groupBox2";
            // 
            // progressBar1
            // 
            this.progressBar1.ForeColor = System.Drawing.Color.SpringGreen;
            this.progressBar1.Location = new System.Drawing.Point(26, 83);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(146, 13);
            this.progressBar1.TabIndex = 2;
            // 
            // btn_CLOSE
            // 
            this.btn_CLOSE.ForeColor = System.Drawing.SystemColors.Desktop;
            this.btn_CLOSE.Location = new System.Drawing.Point(106, 40);
            this.btn_CLOSE.Name = "btn_CLOSE";
            this.btn_CLOSE.Size = new System.Drawing.Size(75, 23);
            this.btn_CLOSE.TabIndex = 1;
            this.btn_CLOSE.Text = "CLOSE";
            this.btn_CLOSE.UseVisualStyleBackColor = true;
            this.btn_CLOSE.Click += new System.EventHandler(this.btn_CLOSE_Click);
            // 
            // btn_OPEN
            // 
            this.btn_OPEN.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btn_OPEN.ForeColor = System.Drawing.SystemColors.Desktop;
            this.btn_OPEN.Location = new System.Drawing.Point(13, 40);
            this.btn_OPEN.Name = "btn_OPEN";
            this.btn_OPEN.Size = new System.Drawing.Size(75, 23);
            this.btn_OPEN.TabIndex = 0;
            this.btn_OPEN.Text = "OPEN";
            this.btn_OPEN.UseVisualStyleBackColor = true;
            this.btn_OPEN.Click += new System.EventHandler(this.btn_OPEN_Click);
            // 
            // btn_SEND
            // 
            this.btn_SEND.Location = new System.Drawing.Point(698, 29);
            this.btn_SEND.Name = "btn_SEND";
            this.btn_SEND.Size = new System.Drawing.Size(74, 37);
            this.btn_SEND.TabIndex = 2;
            this.btn_SEND.Text = "SEND";
            this.btn_SEND.UseVisualStyleBackColor = true;
            this.btn_SEND.Click += new System.EventHandler(this.btn_SEND_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(371, 29);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(312, 98);
            this.textBox1.TabIndex = 3;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label1.ForeColor = System.Drawing.SystemColors.Desktop;
            this.label1.Location = new System.Drawing.Point(368, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 16);
            this.label1.TabIndex = 4;
            this.label1.Text = "Sending";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(371, 234);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(311, 182);
            this.textBox2.TabIndex = 5;
            this.textBox2.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label2.ForeColor = System.Drawing.SystemColors.Desktop;
            this.label2.Location = new System.Drawing.Point(368, 215);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(68, 16);
            this.label2.TabIndex = 6;
            this.label2.Text = "Receiving";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.btn_SEND);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Serial Communication v1.0";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox cBox_BAUDRATE;
        private System.Windows.Forms.ComboBox cBox_PARITYBITS;
        private System.Windows.Forms.ComboBox cBox_STOPBITS;
        private System.Windows.Forms.ComboBox cBox_DATABITS;
        private System.Windows.Forms.Label lbl_PARITYBITS;
        private System.Windows.Forms.Label lbl_STOPBITS;
        private System.Windows.Forms.Label lbl_DATABITS;
        private System.Windows.Forms.Label lbl_BAUDRATE;
        private System.Windows.Forms.Label lbl_PORTNAME;
        private System.Windows.Forms.ComboBox cBox_PORTNAME;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.Button btn_CLOSE;
        private System.Windows.Forms.Button btn_OPEN;
        private System.Windows.Forms.Button btn_SEND;
        private System.Windows.Forms.TextBox textBox1;
        private System.IO.Ports.SerialPort serialPort1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label2;
    }
}

